# SPDX-License-Identifier: GPL-3.0-or-later
import bpy
from bpy.props import BoolProperty, StringProperty, EnumProperty


def _splash_changed(self, context):
    from . import runtime
    runtime.apply_splash(runtime.is_active())


class BSM_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    enabled_mode: BoolProperty(name='Start in Blender Max', default=False)
    studio_colors: BoolProperty(name='Max gray colors', default=True,
        description='Temporarily apply original gray UI colors; restore the previous colors on exit')
    theme_backup: StringProperty(default='', options={'HIDDEN'})
    splash_image: StringProperty(name='Custom Splash Image', subtype='FILE_PATH', update=_splash_changed,
        description="PNG or JPEG shown as Blender's splash screen while Max mode is on. "
                    "Blender's own splash is 1000 x 500 px; the version number is drawn at the top right")
    last_material_editor: EnumProperty(name='Material Editor',items=(('MATERIAL','Slate',''),('COMPACT','Compact','')),default='MATERIAL')

    def draw(self, context):
        from . import runtime
        layout = self.layout
        layout.label(text='Blender Max · 0.6.0 development preview')
        layout.prop(self,'last_material_editor')
        row=layout.row(align=True)
        row.operator('bsm.environment',text='Blender',depress=not runtime.is_active()).mode='BLENDER'
        row.operator('bsm.environment',text='Blender Max',depress=runtime.is_active()).mode='STUDIO'
        row=layout.row()
        row.enabled=not runtime.is_active()
        row.prop(self,'studio_colors')
        layout.label(text='Switch back to Blender before changing the color option.')
        row=layout.row(align=True)
        row.prop(self,'splash_image')
        row.operator('wm.splash',text='',icon='HIDE_OFF')
        layout.label(text='Splash: 1000 x 500 px like the original; used at startup while Max mode is on.')
        layout.label(text='Materials, modifiers and animation use Blender data.',icon='INFO')
        layout.operator('bsm.shortcuts', text='Shortcut Reference',icon='HELP')


CLASSES=(BSM_Preferences,)
