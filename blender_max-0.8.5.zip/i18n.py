# SPDX-License-Identifier: GPL-3.0-or-later
"""Interface translations. Each translations/<locale>.po (zh_HANT.po, de_DE.po...) is
registered with Blender's own translation system, so MaxFlow follows Preferences >
Interface > Translation. Text MaxFlow draws itself goes through tr(); Blender translates
its own widgets. tools/translations.py writes the template translators start from."""
import ast
from pathlib import Path
import bpy

FOLDER = Path(__file__).with_name('translations')
# Text MaxFlow draws is looked up in its own context: Blender's built-in catalog would
# otherwise translate the words it knows (Cone, Plane...) for every language, leaving the
# rest in English, and would win over the translator's choice. Blender's widgets look
# operator names up in "Operator" and other labels in "*": entries go under all three.
CONTEXT = 'MaxFlow'
CONTEXTS = (CONTEXT, '*', 'Operator')
# Codes translators and Poedit use for the Chinese locales Blender names zh_HANT and zh_HANS.
ALIASES = {'zh_TW': 'zh_HANT', 'zh_HK': 'zh_HANT', 'zh_CN': 'zh_HANS', 'zh_SG': 'zh_HANS'}


def parse_po(text):
    """{msgid: msgstr} of a .po file's translated entries; fuzzy and empty ones are skipped."""
    entries, entry, field = {}, {}, None

    def finish():
        if entry.get('msgid') and entry.get('msgstr') and not entry.get('fuzzy'):
            entries[entry['msgid']] = entry['msgstr']
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith(('#,', 'msgctxt ', 'msgid ')) and 'msgstr' in entry:
            finish()
            entry, field = {}, None
        if line.startswith('#,'):
            entry['fuzzy'] = 'fuzzy' in line
        elif line.startswith(('msgctxt ', 'msgid ', 'msgstr ')):
            field, _, value = line.partition(' ')
            entry[field] = ast.literal_eval(value)
        elif line.startswith('"') and field:
            entry[field] += ast.literal_eval(line)
    if 'msgstr' in entry:
        finish()
    return entries


def load(folder=FOLDER):
    """{locale: {(context, msgid): msgstr}} for every .po file in the folder (zh_TW.po counts
    as Blender's zh_HANT; a file named with Blender's own code wins over an alias)."""
    found = {}
    paths = sorted(folder.glob('*.po'), key=lambda p: p.stem not in ALIASES) if folder.is_dir() else ()
    for path in paths:
        entries = parse_po(path.read_text(encoding='utf-8'))
        if entries:
            found.setdefault(ALIASES.get(path.stem, path.stem), {}).update(
                {(context, msgid): msgstr for msgid, msgstr in entries.items() for context in CONTEXTS})
    return found


def tr(text):
    """The interface translation of a label MaxFlow draws itself (unchanged in English)."""
    return bpy.app.translations.pgettext_iface(text, CONTEXT) if text else text


_registered = []


def register(translations=None):
    unregister()
    translations = load() if translations is None else translations
    if translations:
        bpy.app.translations.register(__package__, translations)
        _registered.append(__package__)


def unregister():
    while _registered:
        try:
            bpy.app.translations.unregister(_registered.pop())
        except (ValueError, RuntimeError):
            pass
