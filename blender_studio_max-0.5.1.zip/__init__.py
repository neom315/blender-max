# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender Studio Max: original, reversible studio workflow extension."""
import bpy
__version__ = '0.5.1'
from bpy.props import PointerProperty
from . import max_gizmo
from . import (preferences, params, operators, editors, ui, runtime, chrome, toolbar, interactions, commands, flyouts, quad,
               max_menus, material_ui, animation_ui, utility_editors, scene_ui, trackbar)

CLASSES = (preferences.CLASSES+ui.CLASSES+operators.CLASSES+editors.CLASSES+chrome.CLASSES+toolbar.CLASSES
           +interactions.CLASSES+commands.CLASSES+flyouts.CLASSES+quad.CLASSES+tuple(max_menus.CLASSES)
           +material_ui.CLASSES+animation_ui.CLASSES+utility_editors.CLASSES+scene_ui.CLASSES+trackbar.CLASSES)
CLASSES += max_gizmo.CLASSES
_registered = []


def register():
    try:
        params.register()
        for cls in CLASSES:
            bpy.utils.register_class(cls)
            _registered.append(cls)
        bpy.types.WindowManager.bsm = PointerProperty(type=ui.BSM_State)
        material_ui.register_data()
        bpy.types.TOPBAR_HT_upper_bar.append(ui.draw_switch)
        max_gizmo.register_tool()
        runtime.register()
    except Exception:
        unregister()
        raise


def unregister():
    max_gizmo.unregister_tool()
    runtime.unregister()
    material_ui.unregister_data()
    try:
        bpy.types.TOPBAR_HT_upper_bar.remove(ui.draw_switch)
    except (ValueError, RuntimeError):
        pass
    if hasattr(bpy.types.WindowManager, 'bsm'):
        del bpy.types.WindowManager.bsm
    for cls in reversed(_registered):
        # Gizmo and GizmoGroup classes have no is_registered: try them too.
        if getattr(cls, 'is_registered', True):
            try:
                bpy.utils.unregister_class(cls)
            except RuntimeError:
                pass
    _registered.clear()
    params.unregister()
