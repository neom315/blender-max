# SPDX-License-Identifier: GPL-3.0-or-later
"""Reversible Studio Max viewport bindings, researched against Max 2027.

Only addon-owned entries are touched. No preference or existing keymap mutation.
KEY_TABLE is also the source for the on-screen shortcut reference. Assignments
come from the installed UI_ln/CUI/Default.hsxb; the last column is its action id.
"""

import bpy


def C(command):
    return {'command': command}


# shortcut, label, operator, event, modifiers, operator properties, source action
KEY_TABLE = (
    ("Q", "Select Object", "bsm.tool", "Q", {}, {"tool": "SELECT"}, "647394-SmartSelect`Selection"),
    ("W", "Select and Move", "bsm.tool", "W", {}, {"tool": "MOVE"}, "0-50001"),
    ("E", "Select and Rotate", "bsm.tool", "E", {}, {"tool": "ROTATE"}, "0-50002"),
    ("R", "Select and Scale", "bsm.tool", "R", {}, {"tool": "SCALE"}, "647394-SmartScale`Tools"),
    ("Y", "Select and Place", "bsm.place_surface", "Y", {}, {}, "647394-SmartPlace`Tools"),
    ("1", "Vertex level", "bsm.component", "ONE", {}, {"level": 1}, "647394-SubObject_1`Modifier Stack"),
    ("2", "Edge level", "bsm.component", "TWO", {}, {"level": 2}, "647394-SubObject_2`Modifier Stack"),
    ("3", "Border level", "bsm.component", "THREE", {}, {"level": 3}, "647394-SubObject_3`Modifier Stack"),
    ("4", "Polygon level", "bsm.component", "FOUR", {}, {"level": 4}, "647394-SubObject_4`Modifier Stack"),
    ("5", "Element level", "bsm.component", "FIVE", {}, {"level": 5}, "647394-SubObject_5`Modifier Stack"),
    ("F2", "Shade Selected Faces", "bsm.max_command", "F2", {}, C("SHADE_SELECTED"), "0-371"),
    ("F3", "Wireframe / Smooth + Highlights", "bsm.shading", "F3", {}, {"mode": "WIRE"}, "0-272"),
    ("F4", "Edged Faces", "bsm.shading", "F4", {}, {"mode": "EDGES"}, "0-369"),
    ("G", "Show Grids", "bsm.shading", "G", {}, {"mode": "GRID"}, "0-40077"),
    ("Z", "Zoom Extents Selected", "bsm.frame_selected", "Z", {}, {}, "0-310"),
    ("Ctrl+Alt+Z", "Zoom Extents", "bsm.toolbar_action", "Z", {"ctrl": True, "alt": True}, {"action": "FRAME"}, "0-330"),
    ("Ctrl+Shift+Z", "Zoom Extents All", "bsm.navigation", "Z", {"ctrl": True, "shift": True}, {"kind": "EXTENTS_ALL"}, "0-331"),
    ("Alt+Z", "Zoom", "bsm.navigation", "Z", {"alt": True}, {"kind": "ZOOM"}, "0-50013"),
    ("Ctrl+W", "Zoom Region", "bsm.navigation", "W", {"ctrl": True}, {"kind": "REGION"}, "0-50014"),
    ("Ctrl+P", "Pan View", "bsm.navigation", "P", {"ctrl": True}, {"kind": "PAN"}, "0-40202"),
    ("Ctrl+R", "Orbit", "bsm.navigation", "R", {"ctrl": True}, {"kind": "ORBIT"}, "0-40203"),
    ("[", "Zoom In", "view3d.zoom", "LEFT_BRACKET", {}, {"delta": 1}, "0-321"),
    ("]", "Zoom Out", "view3d.zoom", "RIGHT_BRACKET", {}, {"delta": -1}, "0-320"),
    ("Shift+Z", "Undo View Change", "bsm.max_command", "Z", {"shift": True}, C("UNDO_VIEW"), "0-40104"),
    ("Shift+Y", "Redo View Change", "bsm.max_command", "Y", {"shift": True}, C("REDO_VIEW"), "0-40101"),
    ("F", "Front view", "bsm.view", "F", {}, {"view": "FRONT"}, "0-40060"),
    ("L", "Left view", "bsm.view", "L", {}, {"view": "LEFT"}, "0-40061"),
    ("T", "Top view", "bsm.view", "T", {}, {"view": "TOP"}, "0-40059"),
    ("P", "Perspective view", "bsm.view", "P", {}, {"view": "PERSP"}, "0-40182"),
    ("U", "Orthographic view", "bsm.view", "U", {}, {"view": "ORTHO"}, "0-40183"),
    ("C", "Camera view", "bsm.view", "C", {}, {"view": "CAMERA"}, "0-40068"),
    ("Alt+W", "Maximize Viewport Toggle", "bsm.quad_view", "W", {"alt": True}, {}, "0-50026"),
    ("Ctrl+Alt+X", "Expert Mode", "bsm.max_command", "X", {"ctrl": True, "alt": True}, C("EXPERT_MODE"), "0-40264"),
    ("M", "Material Editor", "bsm.editor", "M", {}, {"kind": "MATERIAL_LAST"}, "0-50048"),
    ("Ctrl+V", "Clone", "bsm.clone", "V", {"ctrl": True}, {}, "0-40213"),
    ("K", "Set Keys", "bsm.keyframe", "K", {}, {"channels": "FILTERED"}, "0-40800"),
    ("N", "Auto Key Mode Toggle", "wm.context_toggle", "N", {}, {"data_path": "scene.tool_settings.use_keyframe_insert_auto"}, "0-50024"),
    (",", "Previous Frame", "screen.frame_offset", "COMMA", {}, {"delta": -1}, "0-50020"),
    (".", "Next Frame", "screen.frame_offset", "PERIOD", {}, {"delta": 1}, "0-50022"),
    ("Ctrl+Shift+N", "Selection Lock Toggle", "bsm.select_lock", "N", {"ctrl": True, "shift": True}, {}, "0-59231"),
    # Not a Max command: Blender's sidebar (add-on panels), on a key Max leaves unassigned.
    ("Shift+N", "Sidebar (Add-on Panels)", "wm.context_toggle", "N", {"shift": True}, {"data_path": "space_data.show_region_ui"}, "unassigned in Max"),
    ("S", "Snaps Toggle", "wm.context_toggle", "S", {}, {"data_path": "tool_settings.use_snap"}, "0-40072"),
    ("A", "Angle Snap Toggle", "wm.context_toggle", "A", {}, {"data_path": "tool_settings.use_snap_rotate"}, "0-40074"),
    ("H", "Select by Name", "bsm.select_from_scene", "H", {}, {}, "0-50029"),
    ("Shift+O", "Window/Crossing Toggle", "wm.context_toggle", "O", {"shift": True}, {"data_path": "window_manager.bsm.window_selection"}, "0-202"),
    ("Ctrl+Shift+A", "Select Similar", "bsm.max_command", "A", {"ctrl": True, "shift": True}, C("SELECT_SIMILAR"), "0-40099"),
    ("Page Up", "Select Ancestor", "object.select_hierarchy", "PAGE_UP", {}, {"direction": "PARENT"}, "0-40193"),
    ("Page Down", "Select Child", "object.select_hierarchy", "PAGE_DOWN", {}, {"direction": "CHILD"}, "0-40194"),
    ("Alt+A", "Align", "bsm.max_command", "A", {"alt": True}, C("ALIGN"), "0-40113"),
    ("Shift+A", "Quick Align", "bsm.max_command", "A", {"shift": True}, C("QUICK_ALIGN"), "0-49"),
    ("Insert", "Affect Pivot Only", "wm.context_toggle", "INSERT", {}, {"data_path": "scene.tool_settings.use_transform_data_origin"}, "647394-PivotMode_Toggle`Tools"),
    ("Alt+Q", "Isolate Selection", "bsm.max_command", "Q", {"alt": True}, C("ISOLATE"), "0-197"),
    ("Alt+H", "Hide Selection", "bsm.toolbar_action", "H", {"alt": True}, {"action": "HIDE"}, "0-223"),
    ("Alt+I", "Hide Unselected", "object.hide_view_set", "I", {"alt": True}, {"unselected": True}, "0-281"),
    ("Alt+U", "Unhide All", "bsm.toolbar_action", "U", {"alt": True}, {"action": "UNHIDE"}, "0-277"),
    ("7", "Show Statistics", "bsm.max_command", "SEVEN", {}, C("XVIEW_STATS"), "0-40829"),
    ("8", "Environment", "bsm.max_command", "EIGHT", {}, C("ENVIRONMENT"), "0-40029"),
    ("X", "Search 3ds Max Commands", "bsm.max_command", "X", {}, C("SEARCH_COMMANDS"), "0-63621"),
    ("Delete", "Delete", "bsm.max_command", "DEL", {}, C("DELETE"), "0-40020"),
    ("Ctrl+H", "Hold", "bsm.max_command", "H", {"ctrl": True}, C("HOLD"), "0-40087"),
    ("Ctrl+Alt+F", "Fetch", "bsm.max_command", "F", {"ctrl": True, "alt": True}, C("FETCH"), "0-40088"),
    ("Ctrl+Y", "Redo", "ed.redo", "Y", {"ctrl": True}, {}, "0-40016"),
    ("F9", "Render Last", "bsm.render_view", "F9", {}, {}, "0-50030"),
    ("Shift+Q", "Render", "bsm.render_view", "Q", {"shift": True}, {}, "menu/toolbar hint: Render"),
    ("F10", "Render Setup", "bsm.editor", "F10", {}, {"kind": "RENDER"}, "0-60010"),
    ("F11", "Scripting Listener", "bsm.editor", "F11", {}, {"kind": "CONSOLE"}, "0-40472"),
    ("F12", "Transform Type-In", "bsm.transform_typein", "F12", {}, {}, "0-40093"),
    ("Home", "Go to Start Frame", "screen.frame_jump", "HOME", {}, {"end": False}, "0-50019"),
    ("End", "Go to End Frame", "screen.frame_jump", "END", {}, {"end": True}, "0-50023"),
    ("/", "Play Animation", "screen.animation_play", "SLASH", {}, {}, "0-50021"),
    ("Ctrl+A", "Select All", "object.select_all", "A", {"ctrl": True}, {"action": "SELECT"}, "0-40021"),
    ("Ctrl+D", "Select None", "object.select_all", "D", {"ctrl": True}, {"action": "DESELECT"}, "0-40043"),
    ("Ctrl+I", "Select Invert", "object.select_all", "I", {"ctrl": True}, {"action": "INVERT"}, "0-40044"),
)
MESH_EQUIVALENT = {'object.select_all': 'mesh.select_all', 'object.hide_view_set': 'mesh.hide', 'object.select_hierarchy': None}

_owned_items = []


def _add(keymap, operator, event, properties=None, value="PRESS", **modifiers):
    item = keymap.keymap_items.new(operator, event, value, head=True, **modifiers)
    # Track before assigning properties so partial failures also clean up.
    _owned_items.append((keymap, item))
    for name, prop_value in (properties or {}).items():
        setattr(item.properties, name, prop_value)
    return item


def register_mode():
    """Activate viewport bindings once; safe in background Blender as well."""
    if _owned_items:
        return
    config = bpy.context.window_manager.keyconfigs.addon
    if config is None:
        return
    try:
        viewport = config.keymaps.new(name="3D View", space_type="VIEW_3D", region_type="WINDOW")
        objects = config.keymaps.new(name="Object Mode", space_type="EMPTY", region_type="WINDOW")
        mesh = config.keymaps.new(name="Mesh", space_type="EMPTY", region_type="WINDOW")
        # Object Mode and Mesh handlers belong to the 3D editor. They must use
        # EMPTY to match Blender's own handler names. Their entries precede
        # Blender's mode-specific E/R/W bindings; text editors are untouched.
        for _, _, operator, event, modifiers, properties, _ in KEY_TABLE:
            if operator in MESH_EQUIVALENT:
                _add(objects, operator, event, properties, **modifiers)
                equivalent = MESH_EQUIVALENT[operator]
                if equivalent:
                    values = {'unselected': True} if equivalent == 'mesh.hide' else properties
                    _add(mesh, equivalent, event, values, **modifiers)
                continue
            for target in (objects, mesh):
                _add(target, operator, event, properties, **modifiers)
        # Shared viewport actions cover non-mesh modes too, subject to operator
        # polls. No global Window/Screen keymaps are registered.
        for _, _, operator, event, modifiers, properties, _ in KEY_TABLE:
            if operator not in MESH_EQUIVALENT:
                _add(viewport, operator, event, properties, **modifiers)
        _add(viewport, "view3d.move", "MIDDLEMOUSE")
        _add(viewport, "view3d.rotate", "MIDDLEMOUSE", alt=True)
        _add(viewport, "view3d.zoom", "MIDDLEMOUSE", ctrl=True, alt=True)
        _add(viewport, "view3d.zoom", "WHEELUPMOUSE", {"delta": 1})
        _add(viewport, "view3d.zoom", "WHEELDOWNMOUSE", {"delta": -1})
        # Mode keymaps run before the 3D View keymap, so the quad replaces each context menu.
        for target in (objects, mesh, viewport):
            _add(target, "bsm.quad_menu", "RIGHTMOUSE")
        for name in ("Curve", "Armature", "Pose", "Lattice", "Font"):
            _add(config.keymaps.new(name=name, space_type="EMPTY", region_type="WINDOW"), "bsm.quad_menu", "RIGHTMOUSE")
    except Exception:
        unregister_mode()
        raise


def set_enabled(on):
    """Keyboard Shortcut Override Toggle: off falls back to Blender's own keys."""
    for _, item in _owned_items:
        try:
            if item.type not in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'RIGHTMOUSE'}:
                item.active = on
        except ReferenceError:
            pass


def unregister_mode():
    """Remove exactly the entries created by register_mode, preserving others."""
    while _owned_items:
        keymap, item = _owned_items.pop()
        try:
            keymap.keymap_items.remove(item)
        except (ReferenceError, RuntimeError):
            # Blender can already have removed a keymap during shutdown/reload.
            pass
