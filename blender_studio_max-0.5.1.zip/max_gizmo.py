# SPDX-License-Identifier: GPL-3.0-or-later
"""Compact Max-style object move handles, using Blender transform operators."""
import bpy
import blf
from mathutils import Matrix, Vector
from bpy_extras.view3d_utils import location_3d_to_region_2d, region_2d_to_location_3d
from . import runtime

_label_positions = {}
_label_handle = None
_tool_registered = False

COLORS = ((.8, .025, .015), (.08, .65, .015), (.015, .04, .85))


class BSM_GT_axis_label(bpy.types.Gizmo):
    bl_idname = 'BSM_GT_axis_label'

    def draw(self, context):
        pass

    def draw_select(self, context, select_id):
        pass

    def test_select(self, context, location):
        return -1


class BSM_GGT_max_move(bpy.types.GizmoGroup):
    bl_idname = 'BSM_GGT_max_move'
    bl_label = 'Max Move Handles'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'3D', 'SCALE'}

    @classmethod
    def poll(cls, context):
        if not runtime.is_active() or context.mode != 'OBJECT' or context.active_object is None or not context.selected_objects:
            return False
        # Only with the Max Select and Move tool, like the axis labels.
        tool = context.workspace.tools.from_space_view3d_mode('OBJECT', create=False)
        return tool is not None and tool.idname == 'bsm.max_move'

    def setup(self, context):
        self.arrows = []
        self.labels = []
        self.planes = []
        for axis in range(3):
            arrow = self.gizmos.new('GIZMO_GT_arrow_3d')
            arrow.draw_style = 'NORMAL'
            arrow.color = COLORS[axis]
            arrow.alpha = 1
            arrow.color_highlight = (1, .85, 0)
            arrow.alpha_highlight = 1
            arrow.line_width = 1.2
            arrow.scale_basis = .30
            op = arrow.target_set_operator('transform.translate')
            op.release_confirm = True
            op.constraint_axis = tuple(i == axis for i in range(3))
            self.arrows.append(arrow)
            label = self.gizmos.new('BSM_GT_axis_label')
            label.axis_text = 'XYZ'[axis]
            label.color = COLORS[axis]
            label.use_draw_modal = True
            self.labels.append(label)
            plane = self.gizmos.new('BSM_GT_move_plane')
            plane.color = COLORS[axis]
            plane.alpha = .9
            plane.color_highlight = (1, .85, 0)
            plane.alpha_highlight = .5
            plane.scale_basis = .30
            plane.line_width = 1
            op = plane.target_set_operator('transform.translate')
            op.release_confirm = True
            op.constraint_axis = tuple(i != axis for i in range(3))
            self.planes.append(plane)

    def draw_prepare(self, context):
        objects = context.selected_objects
        pivot = context.scene.tool_settings.transform_pivot_point
        center = sum((o.matrix_world.translation for o in objects), Vector()) / len(objects)
        if pivot == 'ACTIVE_ELEMENT':
            center = context.active_object.matrix_world.translation.copy()
        elif pivot == 'CURSOR':
            center = context.scene.cursor.location.copy()
        orientation = context.scene.transform_orientation_slots[0].type
        basis = Matrix.Identity(3)
        if orientation in {'LOCAL', 'NORMAL', 'GIMBAL'}:
            basis = context.active_object.matrix_world.to_quaternion().to_matrix()
        elif orientation == 'VIEW':
            basis = context.region_data.view_rotation.to_matrix()
        elif orientation == 'CURSOR':
            basis = context.scene.cursor.rotation_euler.to_matrix()
        custom = context.scene.transform_orientation_slots[0].custom_orientation
        if custom:
            basis = custom.matrix.copy()
        screen = location_3d_to_region_2d(context.region, context.region_data, center)
        unit = 1.0
        if screen is not None:
            unit = (region_2d_to_location_3d(context.region, context.region_data, screen + Vector((112, 0)), center) - center).length
        for i in range(3):
            direction = basis.col[i].normalized()
            rotation = Vector((0, 0, 1)).rotation_difference(direction).to_matrix().to_4x4()
            rotation.translation = center
            self.arrows[i].matrix_basis = rotation
            plane_rotation = Matrix((basis.col[(i+1)%3], basis.col[(i+2)%3], basis.col[i])).transposed().to_4x4()
            plane_rotation.translation = center
            self.planes[i].matrix_basis = plane_rotation
            # Gizmo scale_final keeps the label at the arrow tip when zooming.
            label_matrix = Matrix.Translation(center + direction * unit * 1.1)
            self.labels[i].matrix_basis = label_matrix
        _label_positions[context.region.as_pointer()] = [(label.matrix_basis.translation.copy(), COLORS[i], "XYZ"[i]) for i, label in enumerate(self.labels)]


class BSM_GT_move_plane(bpy.types.Gizmo):
    bl_idname = 'BSM_GT_move_plane'

    def setup(self):
        a, b, c, d = (0, 0, 0), (.28, 0, 0), (.28, .28, 0), (0, .28, 0)
        self.outline = self.new_custom_shape('LINES', (a,b,b,c,c,d,d,a))
        self.surface = self.new_custom_shape('TRIS', (a,b,c,a,c,d))

    def draw(self, context):
        self.draw_custom_shape(self.outline)

    def draw_select(self, context, select_id):
        self.draw_custom_shape(self.surface, select_id=select_id)


CLASSES = (BSM_GT_axis_label, BSM_GT_move_plane, BSM_GGT_max_move)


class BSM_WST_max_move(bpy.types.WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'OBJECT'
    bl_idname = 'bsm.max_move'
    bl_label = 'Select and Move'
    bl_description = 'Move using Max-style axis and plane handles'
    bl_icon = 'ops.transform.translate'
    bl_widget = 'BSM_GGT_max_move'
    bl_keymap = (("view3d.select", {"type": 'LEFTMOUSE', "value": 'PRESS'}, {"properties": [("deselect_all", True)]}),)


def draw_labels():
    context = bpy.context
    if context.mode != 'OBJECT' or not context.region or not context.region_data:
        return
    tool = context.workspace.tools.from_space_view3d_mode(context.mode, create=False)
    if not tool or tool.idname != 'bsm.max_move' or not context.selected_objects:
        return
    for world, color, text in _label_positions.get(context.region.as_pointer(), ()):
        point = location_3d_to_region_2d(context.region, context.region_data, world)
        if point is not None:
            blf.size(0, 14)
            blf.color(0, *color, 1)
            blf.position(0, point.x+3, point.y+3, 0)
            blf.draw(0, text)


def register_tool():
    global _label_handle, _tool_registered
    if not _tool_registered:
        bpy.utils.register_tool(BSM_WST_max_move, after={'builtin.move'})
        _tool_registered = True
    if _label_handle is None:
        _label_handle = bpy.types.SpaceView3D.draw_handler_add(draw_labels, (), 'WINDOW', 'POST_PIXEL')


def unregister_tool():
    """Safe to call when registration stopped part way: register() calls it on failure."""
    global _label_handle, _tool_registered
    if _label_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_label_handle, 'WINDOW')
        _label_handle = None
    if _tool_registered:
        try:
            bpy.utils.unregister_tool(BSM_WST_max_move)
        except (RuntimeError, ValueError, AttributeError):
            pass
        _tool_registered = False
    _label_positions.clear()


def restore_blender_move(context):
    """Leaving Studio mode: Blender's own Move replaces the Max one, whose handles are Studio-only."""
    for window in context.window_manager.windows:
        tool = window.workspace.tools.from_space_view3d_mode('OBJECT', create=False)
        area = next((a for a in window.screen.areas if a.type == 'VIEW_3D'), None)
        if tool is not None and tool.idname == 'bsm.max_move' and area is not None:
            region = next(r for r in area.regions if r.type == 'WINDOW')
            with context.temp_override(window=window, area=area, region=region):
                bpy.ops.wm.tool_set_by_id(name='builtin.move')
